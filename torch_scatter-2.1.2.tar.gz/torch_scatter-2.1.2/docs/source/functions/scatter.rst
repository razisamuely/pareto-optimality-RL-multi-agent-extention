Scatter
=======

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter
