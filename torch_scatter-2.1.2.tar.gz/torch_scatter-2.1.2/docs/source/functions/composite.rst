composite
=========

.. currentmodule:: torch_scatter.composite

.. automodule:: torch_scatter.composite
   :members:
   :undoc-members:
